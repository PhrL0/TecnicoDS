package br.com.senai.controller;

import java.sql.Connection;
import java.sql.DriverManager;

public class Conexao {
	//atributos (contantes) para conexão
	private static final String USERNAME = "root";
	private static final String PASSWORD = "";
	private static final String DATABASE_URL = "jdbc:mysql://localhost:3306/senai";
	
	public static Connection criandoConexao() throws Exception{
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conexao = (Connection) DriverManager.getConnection(DATABASE_URL, USERNAME, PASSWORD);
		return conexao;
	}
	
	public static void main(String[] args) throws Exception {
		//conectando ao BD
		Connection con = criandoConexao();
		if(con != null) {
			System.out.println("Conectado!");
		}else {
			System.out.println("Não conectado");
		}
		con.close();
		
	}

}
