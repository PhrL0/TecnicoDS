package br.com.senai.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import br.com.senai.controller.Conexao;
import br.com.senai.model.Aluno;

public class CrudDAO {
	//CRUD 
	public void create(Aluno aluno){
		//INSERT INTO table_name (column1, column2, column3, ...)
		//VALUES (value1, value2, value3, ...);
		String sql = "INSERT INTO alunos(nome, idade) VALUES (?, ?)";
		Connection conn = null;
		PreparedStatement p = null;
		
		try {
			conn = Conexao.criandoConexao();
			p = (PreparedStatement) conn.prepareStatement(sql);
			p.setString(1, aluno.getNome());
			p.setInt(2, aluno.getIdade());
			p.execute();//se não for add, as informações não vão para o BD
			System.out.println("DADOS INSERIDOS COM SUCESSO");
			
		} catch (Exception e) {//dispara as exceções
			System.out.println("ERRO AO INSERIR DADOS: " + e);
			
		}finally {
			try {
				if(p != null);
				p.close();//fecha a conexão
				
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}
	
	public void update(Aluno aluno) {
		String sql = "UPDATE senai SET nome=?,idade=? WHERE ID < 0";
		Connection conn = null;
		PreparedStatement p = null;
		
		try {
			conn = Conexao.criandoConexao();
			p = (PreparedStatement) conn.prepareStatement(sql);
			p.setString(1, aluno.getNome());
			p.setInt(2, aluno.getIdade());
			p.execute();//se não for add, as informações não vão para o BD
			System.out.println("DADOS ATUALIZADOS COM SUCESSO");
			
		} catch(Exception e) {
			System.out.println("ERRO AO ATUALIZAR DADOS: " + e);
		} finally {
			try {
				if(p != null);
				p.close();//fecha a conexão
				
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	} //UPDATE
	
	public List<Aluno> read(){
		String sql = "SELECT * FROM alunos";
		List<Aluno> alunos = new ArrayList<>();
		Connection conn = null;
		PreparedStatement p = null;
		ResultSet rs = null;
		try {
			conn = Conexao.criandoConexao();
			p = (PreparedStatement) conn.prepareStatement(sql);
			
			rs = p.executeQuery();
			
			while(rs.next()) {
				Aluno ver_aluno = new Aluno();
				
				ver_aluno.setRa(rs.getInt("id"));
				ver_aluno.setNome(rs.getString("nome"));
				ver_aluno.setIdade(rs.getInt("idade"));
				alunos.add(ver_aluno);
			}
				
		}  catch(Exception e) {
			System.out.println("ERRO AO ATUALIZAR DADOS: " + e);
		} finally {
			try {
				if(p != null);
				p.close();//fecha a conexão
				
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		
		return alunos;
	}
	
	public void delete(int ra) {
		String sql = "DELETE FROM alunos WHERE id = ?";
		Connection conn = null;
		PreparedStatement p = null;
		
		
		try {
			conn = Conexao.criandoConexao();
			p = (PreparedStatement) conn.prepareStatement(sql);
			p.setInt(1, ra);
			p.execute();
			
		} catch(Exception e) {
			System.out.println("ERRO AO ATUALIZAR DADOS: " + e);
		} finally {
			try {
				if(p != null);
				p.close();//fecha a conexão
				
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		
	}
	
}
