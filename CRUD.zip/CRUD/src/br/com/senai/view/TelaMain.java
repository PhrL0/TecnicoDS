package br.com.senai.view;

import java.util.Scanner;

import br.com.senai.dao.CrudDAO;
import br.com.senai.model.Aluno;

public class TelaMain {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		//instanciar objs
		CrudDAO crudDAO = new CrudDAO();
		Aluno aluno;
		int option;
		do {
			System.out.println("Escolha uma opção: ");
			System.out.println("1. Inserir aluno");
			System.out.println("2. Atualizar aluno");
			System.out.println("3. Ler aluno");
			System.out.println("4. Deletar aluno");
			System.out.println("5. Sair do programa");
			option = teclado.nextInt();
			teclado.nextLine();//consome linha (buffer)
			
			switch (option) {
			case 1: 
				aluno = new Aluno();
				System.out.println("Digite o nome do aluno: ");
				aluno.setNome(teclado.nextLine());
				
				System.out.println("Digite a idade do aluno: ");
				aluno.setIdade(teclado.nextInt());
				teclado.nextLine();
				
				crudDAO.create(aluno);
				System.out.println("Dados inseridos com sucesso!");
				break;
			case 2: 
				aluno = new Aluno();
				System.out.println("Digite o nome do aluno: ");
				aluno.setNome(teclado.nextLine());
				
				System.out.println("Digite a idade do aluno: ");
				aluno.setIdade(teclado.nextInt());
				teclado.nextLine();
				
				crudDAO.create(aluno);
				System.out.println("Dados atualizados com sucesso!");
				break;
				
			case 3: 
				aluno = new Aluno();
				
				for(Aluno a : crudDAO.read()) {
					System.out.println(a.getNome() + "\n" + a.getIdade());
					
				}
			case 4: 
				aluno = new Aluno();
				System.out.println("Digite o RA para excluir: ");
				int ra = teclado.nextInt();
				teclado.nextLine();
				
				crudDAO.delete(ra);
				break;
				
				
				
				default:
					System.out.println("Digite um número válido.");
					break;
				
			}
			
			
			
		}while(option != 5);
		
		teclado.close();
		
	}

}
