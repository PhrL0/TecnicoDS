import java.util.Scanner;

public class EX6 {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        String input = "";
        double casting = 0;


        try{
            System.out.println("Digite seu valor:");
            input = scan.nextLine();
            casting = Double.parseDouble(input);
        } catch (NumberFormatException e) {
            System.out.println(e.getMessage());
        }

        scan.close();
    }
}
