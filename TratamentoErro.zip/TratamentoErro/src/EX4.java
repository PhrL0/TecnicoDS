import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class EX4 {
    public static void main(String[] args) {
        File file = new File("C:\\Users\\Aluno\\Desktop\\livro.csv");

        Scanner scan = null;

        try {
            scan = new Scanner(file);

            while (scan.hasNextLine()){
                System.out.println(scan.nextLine());
            }

        } catch (FileNotFoundException e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }
}
