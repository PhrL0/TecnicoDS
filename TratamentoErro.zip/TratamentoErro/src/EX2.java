public class EX2 {
}
