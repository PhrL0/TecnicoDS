import java.util.ArrayList;
import java.util.Scanner;

public class EX3 {
    public static void main(String[] args) {
        ArrayList<String> listaAluno = new ArrayList<>();
        int index;
        Scanner scan = new Scanner(System.in);

        listaAluno.add("Pedro");
        listaAluno.add("João");
        try {
            System.out.println("Digite um índice: ");
            index = scan.nextInt();

            System.out.println(listaAluno.get(index));
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println(e.getMessage());
        }

        scan.close();
    }
}
