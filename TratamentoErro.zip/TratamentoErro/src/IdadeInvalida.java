public class IdadeInvalida extends Exception {
    public IdadeInvalida(){
        super("Usuáro de menor!");
    }
}
