import java.util.Scanner;

public class EX5 {
    public static void getIdade(int idade) throws IdadeInvalida {
        if(idade < 18){
            throw new IdadeInvalida();
        }
    }
    public void main(String[] args) throws IdadeInvalida {
        int idade;
        Scanner scan = new Scanner(System.in);

        try {
            System.out.print("Digite sua idade");
            idade = scan.nextInt();
            getIdade(idade);

        } catch (IdadeInvalida idadeInvalida) {
            System.out.println(idadeInvalida.getMessage());
        }

        scan.close();
    }
}
